import pygame
from board import Board
from player import Player

class Game:
    def __init__(self, screen):
        self.screen = screen
        self.board = Board()
        self.players = [Player(0, 4, 0), Player(8, 4, 1)]
        self.current_player = 0

    def handle_event(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN:
            pos = pygame.mouse.get_pos()
            self.board.handle_click(pos, self.players[self.current_player])
            self.current_player = (self.current_player + 1) % 2

    def update(self):
        pass

    def draw(self):
        self.screen.fill((255, 255, 255))
        self.board.draw(self.screen)
        for player in self.players:
            player.draw(self.screen)