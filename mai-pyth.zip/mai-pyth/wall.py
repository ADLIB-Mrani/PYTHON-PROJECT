import pygame

class Wall:
    def __init__(self, x, y, orientation):
        self.x = x
        self.y = y
        self.orientation = orientation
        self.color = (0, 0, 0)
        self.thickness = 10

    def draw(self, screen):
        if self.orientation == 'H':
            rect = pygame.Rect(self.x * 80, self.y * 80 + 35, 160, self.thickness)
        else:
            rect = pygame.Rect(self.x * 80 + 35, self.y * 80, self.thickness, 160)
        pygame.draw.rect(screen, self.color, rect)
        